package assignment1;

public interface Filter {

	boolean accept(String x);
}
